/********************************************************************************
** Form generated from reading UI file 'rbcgui.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RBCGUI_H
#define UI_RBCGUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_RBCGUI
{
public:
    QWidget *centralWidget;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLabel *ParameterCode_label;
    QLabel *Ra_display;
    QLabel *Ra_label;
    QLabel *ColorScheme_label;
    QLabel *Pr_label;
    QLabel *ParemeterCode_display;
    QLabel *Pr_display;
    QLabel *ColorScheme_display;
    QLabel *TimeStep_label;
    QLabel *TimeStep_display;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *para_setting;
    QPushButton *apply_changes;
    QPushButton *visualization;
    QWidget *gridLayoutWidget_2;
    QGridLayout *gridLayout_2;
    QLabel *loadLabel;
    QLabel *statusLabel;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *RBCGUI)
    {
        if (RBCGUI->objectName().isEmpty())
            RBCGUI->setObjectName(QStringLiteral("RBCGUI"));
        RBCGUI->resize(602, 593);
        RBCGUI->setStyleSheet(QStringLiteral(""));
        centralWidget = new QWidget(RBCGUI);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayoutWidget = new QWidget(centralWidget);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(160, 50, 281, 231));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        ParameterCode_label = new QLabel(gridLayoutWidget);
        ParameterCode_label->setObjectName(QStringLiteral("ParameterCode_label"));
        ParameterCode_label->setFrameShape(QFrame::Panel);
        ParameterCode_label->setFrameShadow(QFrame::Raised);

        gridLayout->addWidget(ParameterCode_label, 3, 0, 1, 1);

        Ra_display = new QLabel(gridLayoutWidget);
        Ra_display->setObjectName(QStringLiteral("Ra_display"));
        Ra_display->setFrameShape(QFrame::Panel);
        Ra_display->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(Ra_display, 1, 1, 1, 1);

        Ra_label = new QLabel(gridLayoutWidget);
        Ra_label->setObjectName(QStringLiteral("Ra_label"));
        Ra_label->setFrameShape(QFrame::Panel);
        Ra_label->setFrameShadow(QFrame::Raised);

        gridLayout->addWidget(Ra_label, 1, 0, 1, 1);

        ColorScheme_label = new QLabel(gridLayoutWidget);
        ColorScheme_label->setObjectName(QStringLiteral("ColorScheme_label"));
        ColorScheme_label->setFrameShape(QFrame::Panel);
        ColorScheme_label->setFrameShadow(QFrame::Raised);

        gridLayout->addWidget(ColorScheme_label, 2, 0, 1, 1);

        Pr_label = new QLabel(gridLayoutWidget);
        Pr_label->setObjectName(QStringLiteral("Pr_label"));
        Pr_label->setFrameShape(QFrame::Panel);
        Pr_label->setFrameShadow(QFrame::Raised);

        gridLayout->addWidget(Pr_label, 0, 0, 1, 1);

        ParemeterCode_display = new QLabel(gridLayoutWidget);
        ParemeterCode_display->setObjectName(QStringLiteral("ParemeterCode_display"));
        ParemeterCode_display->setFrameShape(QFrame::Panel);
        ParemeterCode_display->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(ParemeterCode_display, 3, 1, 1, 1);

        Pr_display = new QLabel(gridLayoutWidget);
        Pr_display->setObjectName(QStringLiteral("Pr_display"));
        Pr_display->setFrameShape(QFrame::Panel);
        Pr_display->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(Pr_display, 0, 1, 1, 1);

        ColorScheme_display = new QLabel(gridLayoutWidget);
        ColorScheme_display->setObjectName(QStringLiteral("ColorScheme_display"));
        ColorScheme_display->setFrameShape(QFrame::Panel);
        ColorScheme_display->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(ColorScheme_display, 2, 1, 1, 1);

        TimeStep_label = new QLabel(gridLayoutWidget);
        TimeStep_label->setObjectName(QStringLiteral("TimeStep_label"));
        TimeStep_label->setFrameShape(QFrame::Panel);
        TimeStep_label->setFrameShadow(QFrame::Raised);

        gridLayout->addWidget(TimeStep_label, 4, 0, 1, 1);

        TimeStep_display = new QLabel(gridLayoutWidget);
        TimeStep_display->setObjectName(QStringLiteral("TimeStep_display"));
        TimeStep_display->setFrameShape(QFrame::Panel);
        TimeStep_display->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(TimeStep_display, 4, 1, 1, 1);

        verticalLayoutWidget = new QWidget(centralWidget);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(159, 300, 281, 100));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        para_setting = new QPushButton(verticalLayoutWidget);
        para_setting->setObjectName(QStringLiteral("para_setting"));

        verticalLayout->addWidget(para_setting);

        apply_changes = new QPushButton(verticalLayoutWidget);
        apply_changes->setObjectName(QStringLiteral("apply_changes"));

        verticalLayout->addWidget(apply_changes);

        visualization = new QPushButton(verticalLayoutWidget);
        visualization->setObjectName(QStringLiteral("visualization"));

        verticalLayout->addWidget(visualization);

        gridLayoutWidget_2 = new QWidget(centralWidget);
        gridLayoutWidget_2->setObjectName(QStringLiteral("gridLayoutWidget_2"));
        gridLayoutWidget_2->setGeometry(QRect(110, 430, 371, 51));
        gridLayout_2 = new QGridLayout(gridLayoutWidget_2);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        loadLabel = new QLabel(gridLayoutWidget_2);
        loadLabel->setObjectName(QStringLiteral("loadLabel"));

        gridLayout_2->addWidget(loadLabel, 0, 0, 1, 1);

        statusLabel = new QLabel(gridLayoutWidget_2);
        statusLabel->setObjectName(QStringLiteral("statusLabel"));

        gridLayout_2->addWidget(statusLabel, 0, 1, 1, 1);

        RBCGUI->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(RBCGUI);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 602, 26));
        RBCGUI->setMenuBar(menuBar);
        mainToolBar = new QToolBar(RBCGUI);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        RBCGUI->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(RBCGUI);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        RBCGUI->setStatusBar(statusBar);

        retranslateUi(RBCGUI);

        QMetaObject::connectSlotsByName(RBCGUI);
    } // setupUi

    void retranslateUi(QMainWindow *RBCGUI)
    {
        RBCGUI->setWindowTitle(QApplication::translate("RBCGUI", "RBCGUI", nullptr));
        ParameterCode_label->setText(QApplication::translate("RBCGUI", "parameter code:", nullptr));
        Ra_display->setText(QString());
        Ra_label->setText(QApplication::translate("RBCGUI", "Ra:", nullptr));
        ColorScheme_label->setText(QApplication::translate("RBCGUI", "color scheme:", nullptr));
        Pr_label->setText(QApplication::translate("RBCGUI", "Pr:", nullptr));
        ParemeterCode_display->setText(QString());
        Pr_display->setText(QString());
        ColorScheme_display->setText(QString());
        TimeStep_label->setText(QApplication::translate("RBCGUI", "time step:", nullptr));
        TimeStep_display->setText(QString());
        para_setting->setText(QApplication::translate("RBCGUI", "parameter setting", nullptr));
        apply_changes->setText(QApplication::translate("RBCGUI", "apply changes", nullptr));
        visualization->setText(QApplication::translate("RBCGUI", "visualization", nullptr));
        loadLabel->setText(QApplication::translate("RBCGUI", "loading status:", nullptr));
        statusLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class RBCGUI: public Ui_RBCGUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RBCGUI_H
